# stateless_agent.py

from tools import convert_units

def run_stateless(prompt):
    """
    Expected format:
    Convert 10 m to km
    """

    prompt = prompt.lower()

    try:
        parts = prompt.split()
        value = float(parts[1])
        from_unit = parts[2]
        to_unit = parts[4]
    except:
        raise ValueError("Invalid stateless format.")

    result = convert_units(value, from_unit, to_unit)
    return result