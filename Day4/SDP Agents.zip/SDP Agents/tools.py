# tools.py

def search_constant(name):
    constants = {
        "speed of light": (299792458, "m/s"),
        "gravitational constant": (6.67430e-11, "m^3/kg/s^2"),
        "planck constant": (6.626e-34, "J*s"),
    }

    name = name.lower()

    if name in constants:
        print(f"[Tool] Searching constant: {name}")
        return constants[name]
    else:
        raise ValueError("Constant not found.")


def convert_units(value, from_unit, to_unit):

    print(f"[Tool] Converting {value} from {from_unit} to {to_unit}")

    # Identity conversion
    if from_unit == to_unit:
        return value

    if from_unit == "m/s" and to_unit == "km/h":
        return value * 3.6

    if from_unit == "km/h" and to_unit == "m/s":
        return value / 3.6

    if from_unit == "m" and to_unit == "km":
        return value / 1000

    if from_unit == "km" and to_unit == "m":
        return value * 1000

    raise ValueError("Conversion not supported.")