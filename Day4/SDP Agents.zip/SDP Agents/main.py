# main.py

from stateless_agent import run_stateless
from stateful_agent import run_stateful

def main():
    print("=== Unit Converter Agent Demo ===")
    print("1 → Stateless")
    print("2 → Stateful")
    print("Type exit to quit\n")

    while True:
        mode = input("Choose mode (1 or 2): ")

        if mode.lower() == "exit":
            break

        prompt = input("Ask: ")

        try:
            if mode == "1":
                result = run_stateless(prompt)
                print(f"[Stateless Result] {result}\n")

            elif mode == "2":
                result = run_stateful(prompt)
                print(f"[Stateful Result] {result}\n")

            else:
                print("Invalid mode.\n")

        except Exception as e:
            print("Error:", e)


if __name__ == "__main__":
    main()