# stateful_agent.py

from tools import search_constant, convert_units

def run_stateful(prompt):
    """
    Expected format:
    Convert the speed of light from m/s to km/h
    """

    prompt = prompt.lower()

    # Extract constant name
    constant_name = prompt.split("convert the ")[1].split(" from ")[0]

    # Extract units
    from_unit = prompt.split(" from ")[1].split(" to ")[0]
    to_unit = prompt.split(" to ")[1]

    # Step 1: Search
    value, stored_unit = search_constant(constant_name)

    # Step 2: Convert
    result = convert_units(value, from_unit, to_unit)

    return result